/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instrumentosEntidades;

import java.util.List;

/**
 *
 * @author LENOVO
 */
public class Instrumento {
    String serie;
    String descripcion;
    TipoInstrumento tipo;
    int minimo;
    int maximo;
    int tolerancia;
    List<Calibracion> calibraciones;

    public Instrumento(String serie, String descripcion, TipoInstrumento tipo, int minimo, int maximo, int tolerancia, List<Calibracion> calibraciones) {
        this.serie = serie;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.minimo = minimo;
        this.maximo = maximo;
        this.tolerancia = tolerancia;
        this.calibraciones = calibraciones;
    }

    public Instrumento() {
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public TipoInstrumento getTipo() {
        return tipo;
    }

    public void setTipo(TipoInstrumento tipo) {
        this.tipo = tipo;
        this.tipo.setNombre(tipo.getNombre());
    }
    

    public int getMinimo() {
        return minimo;
    }

    public void setMinimo(int minimo) {
        this.minimo = minimo;
    }

    public int getMaximo() {
        return maximo;
    }

    public void setMaximo(int maximo) {
        this.maximo = maximo;
    }

    public int getTolerancia() {
        return tolerancia;
    }

    public void setTolerancia(int tolerancia) {
        this.tolerancia = tolerancia;
    }

    public List<Calibracion> getCalibraciones() {
        return calibraciones;
    }

    public void setCalibraciones(List<Calibracion> calibraciones) {
        this.calibraciones = calibraciones;
    }
    
    @Override
    public String toString(){
        return this.getDescripcion();
    }    
}
