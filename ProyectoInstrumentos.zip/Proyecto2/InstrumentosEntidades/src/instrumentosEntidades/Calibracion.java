/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instrumentosEntidades;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class Calibracion {
    int numero;
    Instrumento instrumento;
    Date fecha;
    int mediciones;
    List<Medida> medidas;

    public Calibracion(int numero, Instrumento instrumento, Date fecha, int mediciones, List<Medida> medidas) {
        this.numero = numero;
        this.instrumento = instrumento;
        this.fecha = fecha;
        this.mediciones = mediciones;
        this.medidas = medidas;
    }

    public Calibracion() {
       fecha=new Date();
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Instrumento getInstrumento() {
        return instrumento;
    }

    public void setInstrumento(Instrumento instrumento) {
        this.instrumento = instrumento;
    }

    public String getFecha() {
     String sn= new SimpleDateFormat("yyyy-MM-dd").format(fecha);
     return sn;
     
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getMediciones() {
        return mediciones;
    }

    public void setMediciones(int mediciones) {
        this.mediciones = mediciones;
    }

    public List<Medida> getMedidas() {
        return medidas;
    }

    public void setMedidas(List<Medida> medidas) {
        this.medidas = medidas;
    }
    
    private String convertirFechaString(Date date){
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");//cambio
    String fechaComoCadena = sdf.format(date);
    return fechaComoCadena;
    }
    
    public String toString(){
        String s = numero +" "+instrumento.getSerie()+" "+getFecha()+" "+mediciones;
        return s;
    }
    
    
    
}
