/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instrumentos.data;

import instrumentosEntidades.Calibracion;
import instrumentosEntidades.TipoInstrumento;
import instrumentosEntidades.Instrumento;
import instrumentosEntidades.Medida;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Andres
 */
public class Dao {
    RelDatabase db;
    
    public Dao(){
       db = new RelDatabase();
    }
    
    public TipoInstrumento tipoInstrumentoGet(String codigo) throws Exception{
        String sql="select * from TipoInstrumento where codigo='%s'";
        sql = String.format(sql, codigo);
        ResultSet rs = db.executeQuery(sql);
        if(rs.next()){
            return tipoInstrumento(rs);
        }else{
            throw new Exception("Tipo de Instrumento no Existe");
        }
    }
    
    private TipoInstrumento tipoInstrumento(ResultSet rs){//Crea un TipoInstrumento
        try{
            TipoInstrumento ti = new TipoInstrumento();
            ti.setCodigo(rs.getString("codigo"));
            ti.setNombre(rs.getString("nombre"));
            ti.setUnidad(rs.getString("unidad"));
            return ti;
        }
        catch(SQLException e){
            return null;
        }
    }
    
    private Instrumento instrumento(ResultSet rs){
        try{
                Instrumento i = new Instrumento();
                i.setSerie(rs.getString("serie"));
                i.setTipo(tipoInstrumento(rs));
                i.setDescripcion(rs.getString("descripcion"));
                i.setMinimo(rs.getInt("minimo"));
                i.setMaximo(rs.getInt("maximo"));
                i.setTolerancia(rs.getInt("tolerancia"));
                return i;
            }
            catch(SQLException e){
                return null;  
        }
    }
    
    private Calibracion calibracion(ResultSet rs){
        try{
                Calibracion i = new Calibracion();
                i.setNumero(rs.getInt("numero"));
                i.setInstrumento(instrumento(rs));
                i.setFecha(rs.getDate("fecha"));
                i.setMediciones(rs.getInt("mediciones"));
                return i;
            }
            catch(SQLException e){
                return null;  
        }
    }
    
    private Medida medida(ResultSet rs){//Crea un TipoInstrumento
        try{
            Medida m = new Medida();
            m.setLectura(rs.getInt("lectura"));
            m.setReferencia(rs.getInt("referencia"));
            m.setMedida(rs.getInt("medida"));
            return m;
        }
        catch(SQLException e){
            return null;
        }
    }
    
    //////////////////////////////////////////////////////////////////////////////////
    public List<TipoInstrumento> tipoInstrumentoGetAll(){//retorna todos los tipoInstrumento
        List<TipoInstrumento> tInstrumentos = new ArrayList<TipoInstrumento>();
        try{
            String sql="select * from TipoInstrumento";
            ResultSet rs = db.executeQuery(sql);
            while(rs.next()){
                tInstrumentos.add(tipoInstrumento(rs));
            }
        }catch (SQLException e){
            
        }
        return tInstrumentos;
    }
    
    /* Finds the specific instrument*/
    public List<TipoInstrumento> tipoInstrumentoSearch(TipoInstrumento filtro){
      List<TipoInstrumento> resultado = new ArrayList<TipoInstrumento>();
        try {
            String sql="select * from "+"TipoInstrumento p "+//en este caso no se ocupa join?
                    "where p.nombre like '%%%s%%'";
            sql=String.format(sql,filtro.getNombre());
            ResultSet rs =  db.executeQuery(sql);
            while (rs.next()) {
                resultado.add(tipoInstrumento(rs));
            }
        } catch (SQLException ex) { }
        return resultado;
    } 
    
    public void tipoInstrumentoDelete(TipoInstrumento ti) throws Exception{
        String sql="delete from TipoInstrumento where codigo='%s'";
        sql = String.format(sql,ti.getCodigo());
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("TipoInstrumento no existe(borrar)");
        }
    }
    
    public void tipoInstrumentoAdd(TipoInstrumento ti) throws Exception{
        String sql="insert into TipoInstrumento (codigo,nombre,unidad)"+
                "values('%s','%s','%s')";
        sql=String.format(sql,ti.getCodigo(),ti.getNombre(),ti.getUnidad());
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("TipoInstrumento ya existe");
        }
    } 
    
    public void tipoInstrumentoUpdate(TipoInstrumento p) throws Exception{
        String sql="update tipoInstrumento set nombre= '%s',unidad = '%s' "+
                "where codigo='%s'";
        sql=String.format(sql,p.getNombre(),p.getUnidad(),p.getCodigo());
        System.out.println(sql);
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("TipoInstrumento no existe(update)");
        }
    }
    
    ////////////////////////////////////////////////////////////////////////////
    public List<Instrumento> InstrumentoSerch(Instrumento filtro){
        List<Instrumento> resultado = new ArrayList<Instrumento>();
        try {
            String sql="select * from "+"instrumento i inner join tipoinstrumento t on i.tipo=t.codigo "+
                    "where descripcion like '%%%s%%'";
            sql=String.format(sql,filtro.getDescripcion());
            ResultSet rs =  db.executeQuery(sql);
            while (rs.next()) {
                Instrumento aux = instrumento(rs);
                resultado.add(aux);
                aux.setCalibraciones(calibracionGetAll(aux));//crea list de calibraciones
            }
        } catch (SQLException ex) { }
        return resultado;
    
    }
    
     public void instrumentoAdd(Instrumento ti) throws Exception{
        String sql="insert into instrumento (serie,tipo,descripcion,minimo,maximo,tolerancia)"+
                "values('%s','%s','%s','%s','%s','%s')";
        sql=String.format(sql,ti.getSerie(),ti.getTipo().getCodigo(),ti.getDescripcion(),ti.getMinimo(),ti.getMaximo(),ti.getTolerancia());//tambien guardar el tipo de dato
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("Instrumento ya existe");
        }
    } 
     
     
     public void instrumentoUpdate(Instrumento p) throws Exception{
        String sql="update instrumento set tipo= '%s',descripcion = '%s',"
                + " minimo = '%s', maximo = '%s', tolerancia = '%s'"+
                " where serie='%s'";
        sql=String.format(sql,p.getTipo().getCodigo(),p.getDescripcion(),p.getMinimo(),p.getMaximo(),
                p.getTolerancia(),p.getSerie());
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("Instrumento no existe(update)");
        }
    }
     
     public void InstrumentoDelete(Instrumento ti) throws Exception{
        String sql="delete from Instrumento where serie='%s'";
        sql = String.format(sql,ti.getSerie());
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("Instrumento no existe(borrar)");
        }
    }
    
    ////////////////////////////////////////////////////////////////////////////
    
    public void CalibracionAdd(Calibracion ti) throws Exception{
        String sql= "insert into calibracion (numero,instrumento,fecha,mediciones) "
                + "values ('%s','%s','%s','%s')";
        sql=String.format(sql,ti.getNumero(),ti.getInstrumento().getSerie(),ti.getFecha(),ti.getMediciones());//sql=String.format(sql,ti.getNumero(),ti.getInstrumento().getSerie(),ti.getFecha(),ti.getMediciones());
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("Instrumento ya existe");
        }  
    }
    
    public List<Calibracion> calibracionGetAll(Instrumento i){//retorna todos las calibraciones
        List<Calibracion> cali = new ArrayList<Calibracion>();
        try{
            String sql="select * from calibracion c inner join instrumento i on c.instrumento=i.serie"
                    + " inner join tipoinstrumento t on i.tipo=t.codigo where instrumento = '%s'";
            sql=String.format(sql,i.getSerie());
            ResultSet rs = db.executeQuery(sql);
            while(rs.next()){
                cali.add(calibracion(rs));
            }
        }catch (SQLException e){
            
        }
        return cali;
    }
    
    public List<Calibracion> CalibracionSerch(Instrumento filtro){//retorna una lista de calibraciones de un instrumento
        List<Calibracion> resultado = new ArrayList<Calibracion>();
        try {
            String sql="select * from "+"calibracion c inner join instrumento i on c.instrumento=i.serie"
                    + " inner join tipoinstrumento t on i.tipo=t.codigo "+
                    "where serie like '%%%s%%'";
            sql=String.format(sql,filtro.getSerie());
            ResultSet rs =  db.executeQuery(sql);
            while (rs.next()) {
                resultado.add(calibracion(rs));
            }
        } catch (SQLException ex) { }
        return resultado;       
    } 
    
    
    public int maximoNumeroCalibracion(){
        int resultado = 0;
        try {
            String sql= "select * FROM calibracion ORDER BY numero DESC LIMIT 1;";//SELECT MAX(numero) FROM calibracion
            //sql=String.format(sql,filtro.getSerie());
            ResultSet rs =  db.executeQuery(sql);
            while(rs.next()){
                resultado = rs.getInt("numero");
            }
            
        } catch (SQLException ex) { }
        return resultado;
    }
    
     public void calibracionUpdate(Calibracion p) throws Exception{
        String sql="update calibracion set fecha= '%s',mediciones = '%s',"+
                " where numero='%s'";
        sql=String.format(sql,p.getFecha(),p.getMediciones(),p.getNumero());
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("Calibracion no existe(update)");
        }
    }
     
      public void calibracionDelete(Calibracion ti) throws Exception{//borro calibracion y medidas de el
        String sql="delete from calibracion where numero='%s'";
        String sql2="delete from medida where calibracion='%s'";
        sql = String.format(sql,ti.getNumero());
        sql2 = String.format(sql2,ti.getNumero());
        int count=db.executeUpdate(sql);
        int count2=db.executeUpdate(sql2);
        if (count==0 && count2==0){
            throw new Exception("Calibracion no existe(borrar)");
        }
    }
     ///////////////////////////////////////////////////////////////////////////
    public void medidaAdd(Medida ti) throws Exception{
        String sql= "insert into medida (calibracion,medida,referencia,lectura) "
                + "values ('%s','%s','%s','%s')";
        sql=String.format(sql,ti.getCalibracion().getNumero(),
                ti.getMedida(),ti.getReferencia(),ti.getLectura());
        int count=db.executeUpdate(sql);
        if (count==0){
            throw new Exception("Medida ya existe");
        }  
    }
    public List<Medida> medidasSerch(Calibracion filtro){//retorna una lista de calibraciones de un instrumento
        List<Medida> resultado = new ArrayList<Medida>();
        try {
            String sql="select * from  medida m where m.calibracion= '%s'";
            sql=String.format(sql,filtro.getNumero());
            ResultSet rs =  db.executeQuery(sql);
            Medida aux;
            while (rs.next()) {
                aux = medida(rs);
                aux.setCalibracion(filtro);
                aux.setNumero(999);
                resultado.add(aux);
            }
        } catch (SQLException ex) { }
        return resultado;       
    } 
    
    
    
    
    
}
