/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instrumentos.logic;


import instrumentos.data.Dao;
import instrumentosEntidades.Calibracion;
import instrumentosEntidades.Instrumento;
import instrumentosEntidades.Medida;
import instrumentosEntidades.TipoInstrumento;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Escinf
 */
public class Model {
    private Dao dao;
    private HashMap<String,TipoInstrumento> list=new HashMap();
    private HashMap<String,Instrumento> list2=new HashMap();
    private HashMap<Integer,Calibracion> list3=new HashMap();
    private HashMap<Integer,Medida> list4=new HashMap();
    private static Model uniqueInstance;
    
    public static Model instance(){
        if (uniqueInstance == null){
            uniqueInstance = new Model();
        }
        return uniqueInstance;
    }
    private Model(){
        dao = new Dao();
    }
    //=================TIPOS DE INSTRUMENTO==================================
    public List<TipoInstrumento> tipoInstrumentoSerch(TipoInstrumento filtro){
        return dao.tipoInstrumentoSearch(filtro);
    } 
    //----------------------------------------------------------------------
    public void tipoInstrumentoAgregar(TipoInstrumento ti) throws Exception{
        dao.tipoInstrumentoAdd(ti);
    }
    //----------------------------------------------------------------------
    public void tipoInstrumentoActualzar(TipoInstrumento ti) throws Exception{
        dao.tipoInstrumentoUpdate(ti);
    }
    //----------------------------------------------------------------------
    public void tipoInstrumentoBorrar(TipoInstrumento ti) throws Exception{
        dao.tipoInstrumentoDelete(ti);
    }
    //===============INSTRUMENTO===============================
     public List<Instrumento> InstrumentoSerch(Instrumento filtro){ 
        return dao.InstrumentoSerch(filtro);
    } 
    //----------------------------------------------------------------------
    public void InstrumentoAgregar(Instrumento ti) throws Exception{
        dao.instrumentoAdd(ti);
    }
    //----------------------------------------------------------------------
    public void InstrumentoActualzar(Instrumento ti) throws Exception{
        dao.instrumentoUpdate(ti);
    }
    //----------------------------------------------------------------------
    public void InstrumentoBorrar(Instrumento ti) throws Exception{
        dao.InstrumentoDelete(ti);
    }
    //================================================================
      public Collection<TipoInstrumento> getTipoInstrumentos() {
        return dao.tipoInstrumentoGetAll(); //list.values();
      }
    //----------------------------------------------------------------------
    public void CalibracionAgregar(Calibracion ti) throws Exception{
        dao.CalibracionAdd(ti);
    }
    //----------------------------------------------------------------------
    public void CalibracionActualzar(Calibracion ti) throws Exception{
        dao.calibracionUpdate(ti);
    }
    //----------------------------------------------------------------------
    public void CalibracionBorrar(Calibracion ti) throws Exception{
        dao.calibracionDelete(ti);
    }
    //----------------------------------------------------------------------
    public List<Calibracion> CalibracionSerch(Instrumento filtro){
        return dao.CalibracionSerch(filtro);
    } 
    //=================Medidas===================
     public void MedidasAgregar(Medida ti) throws Exception{
        dao.medidaAdd(ti);
    }
    //----------------------------------------------------------------------
    public void MedidasActualzar(Medida ti) throws Exception{
        if (list4.get(ti.getNumero())!=null){
            list4.put(ti.getNumero(), ti);
        }
        else{
            throw new Exception("Calibracion No Existe");
        }
    }
    //----------------------------------------------------------------------
    public void MedidaBorrar(Medida ti) throws Exception{
        if (list4.get(ti.getNumero())!=null){
            list4.remove(ti.getNumero());
        }
        else{
            throw new Exception("Calibracion No Existe");
        }
    }
    //----------------------------------------------------------------------
    public List<Medida> MedidaSerch(Calibracion filtro){
        return dao.medidasSerch(filtro);
    } 
    
    public int numeroMax(){return dao.maximoNumeroCalibracion();}
      
      //public Collection<TipoInstrumento> getTipoInstrumentos() {
}
