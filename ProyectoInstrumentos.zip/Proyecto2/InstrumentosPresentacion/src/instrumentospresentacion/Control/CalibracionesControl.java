/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instrumentospresentacion.Control;

import instrumentos.logic.Model;
import instrumentosEntidades.Calibracion;
import instrumentosEntidades.Medida;
import instrumentospresentacion.Model.CalibracionesModel;
import instrumentospresentacion.Principal;
import instrumentospresentacion.View.CalibracionesView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



/**
 *
 * @author marcovinicio
 */
public class CalibracionesControl {
    CalibracionesView view;
    CalibracionesModel model;
    Model domainModel;

    public CalibracionesControl(Model domainModel,CalibracionesView view, CalibracionesModel model ) {
        model.init();
        this.view = view;
        this.model = model;
        this.domainModel = domainModel;
        view.setControl(this);
        view.setModel(model);
    }
    //========LLena la tabla de medidas con las medidad registradas por cada Calibracion
    public void llenarMedidasAgregadas(int row){
        view.MedidasTable.setEnabled(false);
        view.MedidasTable.enableInputMethods(false);
        Calibracion seleccionada = model.getCalibracionesTM().getRowAt(row);
        model.setCurrent(seleccionada);
        model.clearErrors();
        /*aca debo llamar el domainmodel.searchmedidas*/
        seleccionada.setMedidas(domainModel.MedidaSerch(seleccionada));//nuevo
        List<Medida> rows = seleccionada.getMedidas();//andres
        System.out.println("getmedidas size: "+seleccionada.getMedidas().size());/**/
        model.setMedidasTM(rows);
    }
    //------------------------------------
    public void preAgregar(){
        view.FechaFD.setEnabled(true);
        view.MedicionesFD.setEnabled(true);
        model.clearErrors();
        model.setCurrent(new Calibracion());
    }
    //------------------------------------
    
    public void guardar() throws Exception{
        view.MedidasTable.setEnabled(false);
        view.MedidasTable.enableInputMethods(false);
        
        //================CALIBRACIONES=================
        
        Calibracion nueva=new Calibracion();//Nueva calibracion
        nueva.setInstrumento(model.getFilter());//Instrumento de las calibraciones
        model.clearErrors();
        
        //----Numero Unico para cada Calibracion------
        
        int j=model.getIndiceCalibracion();
        model.setIndiceCalibracion(j+1);
        nueva.setNumero(domainModel.numeroMax()+1);//primer parametro
        
        //----Fecha------------------------------
        
        SimpleDateFormat fT = new SimpleDateFormat("yyyy-MM-dd");
        String strFecha = view.FechaFD.getText();
        Date fecha=null;
        
        try
        {
            fecha=fT.parse(strFecha);
        }
        catch(ParseException ex){
            
            ex.printStackTrace();
        }
        
        nueva.setFecha(fecha);//segundo parametro
         
         if (view.FechaFD.getText().length()==0){
            model.getErrores().put("Fecha", "Fecha requerida");
        }
         
        //-------Numero de Mediciones-------------------
        
        int num=Integer.parseInt(view.MedicionesFD.getText());
        nueva.setMediciones(num);//tercer parametro
        if (view.MedicionesFD.getText().length()==0){
            model.getErrores().put("Medicion", "Medicion requerida");
        }
        
        //======================MEDIDAS======================
        
        List<Medida> meds = model.getMedidasTM().getRows();//lista de medidas de calibracion
       
        /*Inserta los valores que estan en la tabla en la lista
        que maneja los datos en la capa logica*/
        
        for(int i=0;i<meds.size();i++){
            
                //----Numero Unico para cada Calibracion MEDIDA------
                
                int x=model.getIndiceMedicion();
                model.setIndiceMedicion(x+1);
                meds.get(i).setNumero(model.getIndiceMedicion());//le añadimos el atributo numero a medida
                
                //--------------------------------------------
                meds.get(i).setCalibracion(nueva);
                System.out.println("numero de calibracion para la medida a introducir "+meds.get(i).getCalibracion().getNumero());
                //domainModel.MedidasAgregar(meds.get(i));
        }
        nueva.setMedidas(meds);
        
        //===================================================================
        
        List<Calibracion> calibraciones;
        List<Medida> medidas;
        
       // if (model.getErrores().isEmpty()){
       
               
            try{ 
                model.setFilter(Principal.INSTRUMENTOSELECT);
                nueva.setInstrumento(model.getFilter());
                domainModel.CalibracionAgregar(nueva);//pasa algo con el objeto filter
                for(int i=0;i<nueva.getMedidas().size();i++){
                    domainModel.MedidasAgregar(meds.get(i));
                }
                model.setCurrent(nueva);//new Calibracion()
                model.clearErrors();
                calibraciones = domainModel.CalibracionSerch(model.getFilter());//
                medidas=domainModel.MedidaSerch(nueva);/**/
                
                /*Se le agregan las calibraciones al instrumento seleccionado desde el principo*/
                
                model.getFilter().setCalibraciones(calibraciones);
                
                //--------------------------------------------
                
                model.setCalibracionesTM(calibraciones); 
                
                model.setMedidasTM(medidas);/**/
                
                }
            
            catch(Exception e)
            {
                model.getErrores().put("Calibracion", "Calibracion ya existe");
                model.setMensaje("CALIBRACION YA EXISTE");
                model.setCurrent(nueva);
             }      
    }
    
    
    //------------------------------------
    
    public void eliminar() throws Exception{
        int row = view.CalibTable.getSelectedRow();
        model.setCurrent(model.getCalibracionesTM().getRowAt(row));
        System.out.println(model.getCurrent().getFecha());
        domainModel.CalibracionBorrar(model.getCurrent());
        model.notifyObservers();
    }
    
    //------------------------------------
    public void establecerMedidas(int tam){
        view.FechaFD.setEnabled(true);
        view.MedicionesFD.setEnabled(true);
        List<Medida> medidas=new ArrayList<Medida>();
        for(int i=0;i<tam;i++){
            Medida m=new Medida();
            medidas.add(m);
        }
        model.setMedidasTM(medidas);
    }
    //------------------------------------
   /* public void agregaMedidas(int row,int col,int ref,int lec){
        
    }*/
    public void editarTabla(Object value,int row,int colum) throws Exception{
        model.getMedidasTM().setValueAt(value, row, colum);
    }
  
}
