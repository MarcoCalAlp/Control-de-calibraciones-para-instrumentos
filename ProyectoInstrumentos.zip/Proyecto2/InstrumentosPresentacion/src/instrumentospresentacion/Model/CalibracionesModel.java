/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instrumentospresentacion.Model;

import instrumentosEntidades.Calibracion;
import instrumentosEntidades.Instrumento;
import instrumentosEntidades.Medida;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author marcovinicio
 */
public class CalibracionesModel extends Observable {
    
    //------MANEJO DE ERRORES--
    HashMap<String,String> errores;
    String mensaje;
    //-------MEDIDAS-----------
    Calibracion current;
    MedidaTableModel medidasTM;
    int indiceMedicion;
    //------CALIBRACIONES------
    Instrumento filter;
    CalibracionTableModel calibracionesTM;
    int indiceCalibracion;
    

    public CalibracionesModel() {
        
    }
    
    public void init(){ 
        //=======MANTENIMIENTO MEDIDAS========
        current = new Calibracion();
        List<Medida> rowsM = new ArrayList<Medida>();
        this.setMedidasTM(rowsM);
        indiceMedicion=0;
        //======MANTENIMIENTO CALIBRACIONES====
        filter=new Instrumento();
        List<Calibracion> rowsC = new ArrayList<Calibracion>();
        this.setCalibracionesTM(rowsC);
        indiceCalibracion=0;
        //===================================
        
        clearErrors();
    }
    //============MEDIDAS METODOS=======================
     public void setMedidasTM(List<Medida> medidas){
        int[] cols={MedidaTableModel.REFERENCIA,MedidaTableModel.LECTURA};
        this.medidasTM =new MedidaTableModel(cols,medidas);  
        setChanged();
        notifyObservers();        
    }
     //-----------------------------------
     public MedidaTableModel getMedidasTM() {
        return medidasTM;
    }
     //-----------------------------------
    public Calibracion getCurrent() {
        return current;
    }
    //-----------------------------------
    public void setCurrent(Calibracion current) {
        this.current = current;
        setChanged();
        notifyObservers(); 
    }
    //----------------------------------
    public int getIndiceMedicion() {    
        return indiceMedicion;
    }

    //----------------------------------
    public void setIndiceMedicion(int indiceMedicion) {    
        this.indiceMedicion = indiceMedicion;
    }

    //==============CALIBRACIONES METODOS================
    public void setCalibracionesTM(List<Calibracion> calibraciones) {
        int[] cols={CalibracionTableModel.FECHA,CalibracionTableModel.MEDICIONES};
        this.calibracionesTM=new CalibracionTableModel(cols,calibraciones);
        setChanged();
        notifyObservers();
    }
    //-----------------------------------
    public CalibracionTableModel getCalibracionesTM() {
        return calibracionesTM;
    }
    //----------------------------------
    public Instrumento getFilter() {
        return filter;
    }
    //----------------------------------
    public void setFilter(Instrumento filter) {
        this.filter = filter;
        setChanged();
        notifyObservers(); 
    }
    //--------------------------------
    public int getIndiceCalibracion() {
        return indiceCalibracion;
    }
    //------------------------------------
     public void setIndiceCalibracion(int indice) {
        this.indiceCalibracion = indice;
    }
    //==========ERRORES METODOS==========================
    public HashMap<String, String> getErrores() {
        return errores;
    }
    //-----------------------------------
    public void setErrores(HashMap<String, String> errores) {
        this.errores = errores;
    }
    //----------------------------------
    public String getMensaje() {
        return mensaje;
    }
    //-----------------------------------
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    //-----------------------------------
    public void clearErrors(){
        setErrores(new HashMap<String,String>());
        setMensaje(""); 
    }
    //-----------------------------------
    @Override
    public void addObserver(Observer o) {
        super.addObserver(o);
        setChanged();
        notifyObservers();
    }
    //-----------------------------------

    public void recuperar(Instrumento t){
        setFilter(t);
        setCalibracionesTM(t.getCalibraciones());
        setCurrent(new Calibracion());
        setMedidasTM(new ArrayList<Medida>());
    }
    
    
}
