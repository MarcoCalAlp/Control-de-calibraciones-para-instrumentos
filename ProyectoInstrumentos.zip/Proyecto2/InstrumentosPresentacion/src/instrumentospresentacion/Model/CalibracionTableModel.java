/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instrumentospresentacion.Model;

import instrumentosEntidades.Calibracion;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author marcovinicio
 */
public class CalibracionTableModel extends AbstractTableModel {
    
    List<Calibracion> rows;
    int[] cols;
    //===========METODOS======================
    public  CalibracionTableModel(int[] cols, List<Calibracion> rows){
        this.cols=cols;
        this.rows=rows;
        initColNames();
    }
    //----------------------------------------
    @Override
    public int getRowCount() {
     return rows.size();  
    }
    //----------------------------------------
    @Override
    public int getColumnCount() {
     return cols.length;   
    }
    //----------------------------------------
    @Override
    public Object getValueAt(int row, int col) {
     Calibracion obj = rows.get(row);
        switch (cols[col]){
            case NUMERO: return obj.getNumero();
            case INSTRUMENTO: return obj.getInstrumento();
            case FECHA: return obj.getFecha();
            case MEDICIONES: return obj.getMediciones();
            default: return "";
        }  
    }
    //-------------------------------------
    public String getColumnName(int col){
        return colNames[cols[col]];
    }
    //-------------------------------------
    public Class<?> getColumnClass(int col){
        switch (cols[col]){
            default: return super.getColumnClass(col);
        }    
    }    
    
    //----------------------------------------
    public Calibracion getRowAt(int row) {
        return rows.get(row);
    }
    //-------VARIABLES ESTATICAS--------------
    public static final int NUMERO=0;
    public static final int INSTRUMENTO=1;
    public static final int FECHA=2;
    public static final int MEDICIONES=3;
    //-----------------------------------------
    String[] colNames = new String[4];
    private void initColNames(){
        colNames[NUMERO]= "Numero";
        colNames[INSTRUMENTO]= "Instrumento";
        colNames[FECHA]= "Fecha";
        colNames[MEDICIONES]= "Mediciones";
    }
            
    
}
